-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : ven. 10 oct. 2025 à 19:05
-- Version du serveur : 10.4.32-MariaDB
-- Version de PHP : 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `pegase`
--

-- --------------------------------------------------------

--
-- Structure de la table `passwords`
--

CREATE TABLE `passwords` (
  `password_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `recipient_email` varchar(100) NOT NULL,
  `is_used` tinyint(1) DEFAULT 0,
  `status` enum('active','used','expired') DEFAULT 'active',
  `expiration_time` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `used_at` timestamp NULL DEFAULT NULL,
  `password_key` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `passwords`
--

INSERT INTO `passwords` (`password_id`, `user_id`, `recipient_email`, `is_used`, `status`, `expiration_time`, `created_at`, `used_at`, `password_key`) VALUES
(10, 1, 'aicursor86@gmail.com', 0, 'expired', '2025-08-12 11:05:36', '2025-08-12 11:04:36', NULL, NULL),
(11, 1, 'ilyasbelkhadir12345@gmail.com', 0, 'expired', '2025-08-12 11:06:27', '2025-08-12 11:05:27', NULL, NULL),
(12, 1, 'ilyasbelkhadir12345@gmail.com', 0, 'expired', '2025-08-12 11:13:18', '2025-08-12 11:12:18', NULL, NULL),
(13, 1, 'ilyasbelkhadir12345@gmail.com', 0, 'used', '2025-08-12 13:34:50', '2025-08-12 13:33:50', NULL, NULL),
(14, 1, 'ilyasbelkhadir12345@gmail.com', 1, 'used', '2025-08-12 13:44:33', '2025-08-12 13:43:33', '2025-08-12 13:44:02', 'c4fb070d97c36fb2bcf279f04523dc42'),
(15, 1, 'ilyasbelkhadir12345@gmail.com', 0, 'expired', '2025-08-12 13:52:48', '2025-08-12 13:47:48', NULL, NULL),
(16, 1, 'ilyasbelkhadir12345@gmail.com', 1, 'used', '2025-08-12 13:50:52', '2025-08-12 13:49:52', '2025-08-12 13:50:05', 'dfc6040a267c5d989514e8195eeb7fcf'),
(17, 1, 'aicursor86@gmail.com', 0, 'active', '2025-10-10 16:56:00', '2025-10-10 16:55:00', NULL, 'c5ea298707f927cf98847e3e92c58826');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `status` enum('active','inactive','suspended') DEFAULT 'active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `last_login` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`user_id`, `username`, `email`, `password`, `status`, `created_at`, `updated_at`, `last_login`) VALUES
(1, 'ilyas_belkhadir', 'ilyasbelkhadir1234@gmail.com', '$2b$10$7CMdwKKEXkpSmx0KZNYdZed4vwsGnW/H4zI7j9LPX/80DIt8q8P3S', 'active', '2025-08-04 13:37:25', '2025-10-10 16:54:49', '2025-10-10 16:54:49');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `passwords`
--
ALTER TABLE `passwords`
  ADD PRIMARY KEY (`password_id`),
  ADD KEY `idx_user_id` (`user_id`),
  ADD KEY `idx_recipient_email` (`recipient_email`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_expiration_time` (`expiration_time`),
  ADD KEY `idx_created_at` (`created_at`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `idx_email` (`email`),
  ADD KEY `idx_username` (`username`),
  ADD KEY `idx_status` (`status`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `passwords`
--
ALTER TABLE `passwords`
  MODIFY `password_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `passwords`
--
ALTER TABLE `passwords`
  ADD CONSTRAINT `passwords_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE SET NULL;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
